# Proyecto Juego
##  Tags:   
	Version1 generada por Carla
	Version1 verificada por Joaquin
	Version1 comuniacada por Adrià
	URL del video: https://youtu.be/3z8-RbdUEK4


	Version2 generada por Adria
	Version2 verificada por Carla
	Version2 comuniacada por Joaquin
	URL del video: https://youtu.be/72AJRhfhlrk


	Version3 generada por Joaquin
	Version3 verificada por Adria
	Version3 comuniacada por Carla
	URL del video: https://youtu.be/Y19V3ti6-YI

	Version4 generada por Carla
	Version4 verificada por Joaquin
	Version4 comunicada por Adria
	URL del video: https://youtu.be/hMqxdOYHEXc

	Version5 generada por Adria
	Version5 verificada por Carla
	Version5 comunicada por Joaquin
	URL del video: https://youtu.be/EX4WxxQIGBU 

	Version6 generada por Joaquin


	
