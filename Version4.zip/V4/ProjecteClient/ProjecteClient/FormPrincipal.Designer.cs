﻿
namespace ProjecteClient
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.ConexionActual = new System.Windows.Forms.Panel();
            this.ListaConectados = new System.Windows.Forms.DataGridView();
            this.GroupLogSignInBox = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.LogSignInBtn = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.InvitacionBox = new System.Windows.Forms.GroupBox();
            this.InvitacionLbl2 = new System.Windows.Forms.Label();
            this.RejectGameBtn = new System.Windows.Forms.Button();
            this.GameAcceptBtn = new System.Windows.Forms.Button();
            this.InvitacionLbl1 = new System.Windows.Forms.Label();
            this.GrupoJuegoBox = new System.Windows.Forms.GroupBox();
            this.TuColorLbl = new System.Windows.Forms.Label();
            this.LocalMsg = new System.Windows.Forms.TextBox();
            this.LocalScreen = new System.Windows.Forms.TextBox();
            this.Usuariolbl = new System.Windows.Forms.Label();
            this.GlobalScreen = new System.Windows.Forms.TextBox();
            this.GlobalMsg = new System.Windows.Forms.TextBox();
            this.GlobalBtn = new System.Windows.Forms.Button();
            this.ChatGlobalBox = new System.Windows.Forms.GroupBox();
            this.Invitadoslbl = new System.Windows.Forms.Label();
            this.AnadirInvitadoBtn = new System.Windows.Forms.Button();
            this.ChatLocalBox = new System.Windows.Forms.GroupBox();
            this.LocalBtn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.EmpezarPartidaBtn = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.PictureBox();
            this.A2 = new System.Windows.Forms.PictureBox();
            this.B1 = new System.Windows.Forms.PictureBox();
            this.A1 = new System.Windows.Forms.PictureBox();
            this.F6 = new System.Windows.Forms.PictureBox();
            this.E6 = new System.Windows.Forms.PictureBox();
            this.D6 = new System.Windows.Forms.PictureBox();
            this.C6 = new System.Windows.Forms.PictureBox();
            this.F5 = new System.Windows.Forms.PictureBox();
            this.E5 = new System.Windows.Forms.PictureBox();
            this.D5 = new System.Windows.Forms.PictureBox();
            this.C5 = new System.Windows.Forms.PictureBox();
            this.F4 = new System.Windows.Forms.PictureBox();
            this.F3 = new System.Windows.Forms.PictureBox();
            this.E4 = new System.Windows.Forms.PictureBox();
            this.D4 = new System.Windows.Forms.PictureBox();
            this.C4 = new System.Windows.Forms.PictureBox();
            this.E3 = new System.Windows.Forms.PictureBox();
            this.B5 = new System.Windows.Forms.PictureBox();
            this.B4 = new System.Windows.Forms.PictureBox();
            this.A6 = new System.Windows.Forms.PictureBox();
            this.A3 = new System.Windows.Forms.PictureBox();
            this.B6 = new System.Windows.Forms.PictureBox();
            this.C3 = new System.Windows.Forms.PictureBox();
            this.A5 = new System.Windows.Forms.PictureBox();
            this.B3 = new System.Windows.Forms.PictureBox();
            this.A4 = new System.Windows.Forms.PictureBox();
            this.D3 = new System.Windows.Forms.PictureBox();
            this.E1 = new System.Windows.Forms.PictureBox();
            this.E2 = new System.Windows.Forms.PictureBox();
            this.D2 = new System.Windows.Forms.PictureBox();
            this.C2 = new System.Windows.Forms.PictureBox();
            this.F2 = new System.Windows.Forms.PictureBox();
            this.F1 = new System.Windows.Forms.PictureBox();
            this.D1 = new System.Windows.Forms.PictureBox();
            this.C1 = new System.Windows.Forms.PictureBox();
            this.PColorBox = new System.Windows.Forms.PictureBox();
            this.DisconectBtn = new System.Windows.Forms.Button();
            this.SigInBtn = new System.Windows.Forms.Button();
            this.LogInBtn = new System.Windows.Forms.Button();
            this.Connect_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ListaConectados)).BeginInit();
            this.GroupLogSignInBox.SuspendLayout();
            this.InvitacionBox.SuspendLayout();
            this.GrupoJuegoBox.SuspendLayout();
            this.ChatGlobalBox.SuspendLayout();
            this.ChatLocalBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.B2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.A4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.E2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PColorBox)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(5, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Conexión";
            // 
            // ConexionActual
            // 
            this.ConexionActual.Location = new System.Drawing.Point(80, 6);
            this.ConexionActual.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ConexionActual.Name = "ConexionActual";
            this.ConexionActual.Size = new System.Drawing.Size(23, 25);
            this.ConexionActual.TabIndex = 10;
            // 
            // ListaConectados
            // 
            this.ListaConectados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ListaConectados.Location = new System.Drawing.Point(398, 48);
            this.ListaConectados.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ListaConectados.Name = "ListaConectados";
            this.ListaConectados.RowHeadersWidth = 51;
            this.ListaConectados.RowTemplate.Height = 24;
            this.ListaConectados.Size = new System.Drawing.Size(175, 231);
            this.ListaConectados.TabIndex = 14;
            this.ListaConectados.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ListaConectados_CellContentClick);
            this.ListaConectados.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ListaConectados_CellDoubleClick);
            // 
            // GroupLogSignInBox
            // 
            this.GroupLogSignInBox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.GroupLogSignInBox.Controls.Add(this.textBox3);
            this.GroupLogSignInBox.Controls.Add(this.label4);
            this.GroupLogSignInBox.Controls.Add(this.LogSignInBtn);
            this.GroupLogSignInBox.Controls.Add(this.textBox2);
            this.GroupLogSignInBox.Controls.Add(this.textBox4);
            this.GroupLogSignInBox.Controls.Add(this.label5);
            this.GroupLogSignInBox.Controls.Add(this.label6);
            this.GroupLogSignInBox.Location = new System.Drawing.Point(11, 326);
            this.GroupLogSignInBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GroupLogSignInBox.Name = "GroupLogSignInBox";
            this.GroupLogSignInBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GroupLogSignInBox.Size = new System.Drawing.Size(326, 152);
            this.GroupLogSignInBox.TabIndex = 15;
            this.GroupLogSignInBox.TabStop = false;
            this.GroupLogSignInBox.Text = "groupBox1";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(96, 107);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(89, 22);
            this.textBox3.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "label4";
            // 
            // LogSignInBtn
            // 
            this.LogSignInBtn.Location = new System.Drawing.Point(214, 39);
            this.LogSignInBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LogSignInBtn.Name = "LogSignInBtn";
            this.LogSignInBtn.Size = new System.Drawing.Size(104, 48);
            this.LogSignInBtn.TabIndex = 8;
            this.LogSignInBtn.Text = "Cerrar";
            this.LogSignInBtn.UseVisualStyleBackColor = true;
            this.LogSignInBtn.Click += new System.EventHandler(this.LogSignInBtn_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(96, 69);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(89, 22);
            this.textBox2.TabIndex = 3;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(96, 36);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(89, 22);
            this.textBox4.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "label6";
            // 
            // InvitacionBox
            // 
            this.InvitacionBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.InvitacionBox.Controls.Add(this.InvitacionLbl2);
            this.InvitacionBox.Controls.Add(this.RejectGameBtn);
            this.InvitacionBox.Controls.Add(this.GameAcceptBtn);
            this.InvitacionBox.Controls.Add(this.InvitacionLbl1);
            this.InvitacionBox.Location = new System.Drawing.Point(11, 482);
            this.InvitacionBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.InvitacionBox.Name = "InvitacionBox";
            this.InvitacionBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.InvitacionBox.Size = new System.Drawing.Size(326, 128);
            this.InvitacionBox.TabIndex = 18;
            this.InvitacionBox.TabStop = false;
            this.InvitacionBox.Text = "Invitacion";
            this.InvitacionBox.Enter += new System.EventHandler(this.InvitacionBox_Enter);
            // 
            // InvitacionLbl2
            // 
            this.InvitacionLbl2.AutoSize = true;
            this.InvitacionLbl2.Location = new System.Drawing.Point(147, 58);
            this.InvitacionLbl2.Name = "InvitacionLbl2";
            this.InvitacionLbl2.Size = new System.Drawing.Size(44, 16);
            this.InvitacionLbl2.TabIndex = 3;
            this.InvitacionLbl2.Text = "label8";
            // 
            // RejectGameBtn
            // 
            this.RejectGameBtn.Location = new System.Drawing.Point(227, 82);
            this.RejectGameBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.RejectGameBtn.Name = "RejectGameBtn";
            this.RejectGameBtn.Size = new System.Drawing.Size(77, 38);
            this.RejectGameBtn.TabIndex = 2;
            this.RejectGameBtn.Text = "Rechazar";
            this.RejectGameBtn.UseVisualStyleBackColor = true;
            this.RejectGameBtn.Click += new System.EventHandler(this.RejectGameBtn_Click);
            // 
            // GameAcceptBtn
            // 
            this.GameAcceptBtn.Location = new System.Drawing.Point(36, 82);
            this.GameAcceptBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GameAcceptBtn.Name = "GameAcceptBtn";
            this.GameAcceptBtn.Size = new System.Drawing.Size(73, 38);
            this.GameAcceptBtn.TabIndex = 1;
            this.GameAcceptBtn.Text = "Aceptar";
            this.GameAcceptBtn.UseVisualStyleBackColor = true;
            this.GameAcceptBtn.Click += new System.EventHandler(this.GameAcceptBtn_Click);
            // 
            // InvitacionLbl1
            // 
            this.InvitacionLbl1.AutoSize = true;
            this.InvitacionLbl1.Location = new System.Drawing.Point(72, 32);
            this.InvitacionLbl1.Name = "InvitacionLbl1";
            this.InvitacionLbl1.Size = new System.Drawing.Size(183, 16);
            this.InvitacionLbl1.TabIndex = 0;
            this.InvitacionLbl1.Text = "Te está invitando a su partida";
            // 
            // GrupoJuegoBox
            // 
            this.GrupoJuegoBox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.GrupoJuegoBox.Controls.Add(this.B2);
            this.GrupoJuegoBox.Controls.Add(this.A2);
            this.GrupoJuegoBox.Controls.Add(this.B1);
            this.GrupoJuegoBox.Controls.Add(this.A1);
            this.GrupoJuegoBox.Controls.Add(this.F6);
            this.GrupoJuegoBox.Controls.Add(this.E6);
            this.GrupoJuegoBox.Controls.Add(this.D6);
            this.GrupoJuegoBox.Controls.Add(this.C6);
            this.GrupoJuegoBox.Controls.Add(this.F5);
            this.GrupoJuegoBox.Controls.Add(this.E5);
            this.GrupoJuegoBox.Controls.Add(this.D5);
            this.GrupoJuegoBox.Controls.Add(this.C5);
            this.GrupoJuegoBox.Controls.Add(this.F4);
            this.GrupoJuegoBox.Controls.Add(this.F3);
            this.GrupoJuegoBox.Controls.Add(this.E4);
            this.GrupoJuegoBox.Controls.Add(this.D4);
            this.GrupoJuegoBox.Controls.Add(this.C4);
            this.GrupoJuegoBox.Controls.Add(this.E3);
            this.GrupoJuegoBox.Controls.Add(this.B5);
            this.GrupoJuegoBox.Controls.Add(this.B4);
            this.GrupoJuegoBox.Controls.Add(this.A6);
            this.GrupoJuegoBox.Controls.Add(this.A3);
            this.GrupoJuegoBox.Controls.Add(this.B6);
            this.GrupoJuegoBox.Controls.Add(this.C3);
            this.GrupoJuegoBox.Controls.Add(this.A5);
            this.GrupoJuegoBox.Controls.Add(this.B3);
            this.GrupoJuegoBox.Controls.Add(this.A4);
            this.GrupoJuegoBox.Controls.Add(this.D3);
            this.GrupoJuegoBox.Controls.Add(this.E1);
            this.GrupoJuegoBox.Controls.Add(this.E2);
            this.GrupoJuegoBox.Controls.Add(this.D2);
            this.GrupoJuegoBox.Controls.Add(this.C2);
            this.GrupoJuegoBox.Controls.Add(this.F2);
            this.GrupoJuegoBox.Controls.Add(this.F1);
            this.GrupoJuegoBox.Controls.Add(this.D1);
            this.GrupoJuegoBox.Controls.Add(this.C1);
            this.GrupoJuegoBox.Controls.Add(this.PColorBox);
            this.GrupoJuegoBox.Controls.Add(this.TuColorLbl);
            this.GrupoJuegoBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.GrupoJuegoBox.Location = new System.Drawing.Point(866, 6);
            this.GrupoJuegoBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GrupoJuegoBox.Name = "GrupoJuegoBox";
            this.GrupoJuegoBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GrupoJuegoBox.Size = new System.Drawing.Size(816, 613);
            this.GrupoJuegoBox.TabIndex = 45;
            this.GrupoJuegoBox.TabStop = false;
            this.GrupoJuegoBox.Text = "Juego";
            // 
            // TuColorLbl
            // 
            this.TuColorLbl.AutoSize = true;
            this.TuColorLbl.Location = new System.Drawing.Point(645, 36);
            this.TuColorLbl.Name = "TuColorLbl";
            this.TuColorLbl.Size = new System.Drawing.Size(58, 16);
            this.TuColorLbl.TabIndex = 62;
            this.TuColorLbl.Text = "Tu Color";
            // 
            // LocalMsg
            // 
            this.LocalMsg.Location = new System.Drawing.Point(6, 242);
            this.LocalMsg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LocalMsg.Multiline = true;
            this.LocalMsg.Name = "LocalMsg";
            this.LocalMsg.Size = new System.Drawing.Size(160, 42);
            this.LocalMsg.TabIndex = 46;
            // 
            // LocalScreen
            // 
            this.LocalScreen.Location = new System.Drawing.Point(6, 18);
            this.LocalScreen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LocalScreen.Multiline = true;
            this.LocalScreen.Name = "LocalScreen";
            this.LocalScreen.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.LocalScreen.Size = new System.Drawing.Size(216, 220);
            this.LocalScreen.TabIndex = 47;
            // 
            // Usuariolbl
            // 
            this.Usuariolbl.AutoSize = true;
            this.Usuariolbl.Font = new System.Drawing.Font("Mongolian Baiti", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Usuariolbl.Location = new System.Drawing.Point(109, 9);
            this.Usuariolbl.Name = "Usuariolbl";
            this.Usuariolbl.Size = new System.Drawing.Size(53, 14);
            this.Usuariolbl.TabIndex = 49;
            this.Usuariolbl.Text = "Usuario:";
            // 
            // GlobalScreen
            // 
            this.GlobalScreen.Location = new System.Drawing.Point(6, 21);
            this.GlobalScreen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GlobalScreen.Multiline = true;
            this.GlobalScreen.Name = "GlobalScreen";
            this.GlobalScreen.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.GlobalScreen.Size = new System.Drawing.Size(212, 217);
            this.GlobalScreen.TabIndex = 50;
            // 
            // GlobalMsg
            // 
            this.GlobalMsg.Location = new System.Drawing.Point(8, 242);
            this.GlobalMsg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GlobalMsg.Multiline = true;
            this.GlobalMsg.Name = "GlobalMsg";
            this.GlobalMsg.Size = new System.Drawing.Size(153, 42);
            this.GlobalMsg.TabIndex = 51;
            // 
            // GlobalBtn
            // 
            this.GlobalBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GlobalBtn.Location = new System.Drawing.Point(167, 242);
            this.GlobalBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GlobalBtn.Name = "GlobalBtn";
            this.GlobalBtn.Size = new System.Drawing.Size(51, 42);
            this.GlobalBtn.TabIndex = 52;
            this.GlobalBtn.Text = "Enviar\r\n";
            this.GlobalBtn.UseVisualStyleBackColor = true;
            this.GlobalBtn.Click += new System.EventHandler(this.GlobalBtn_Click);
            // 
            // ChatGlobalBox
            // 
            this.ChatGlobalBox.Controls.Add(this.GlobalMsg);
            this.ChatGlobalBox.Controls.Add(this.GlobalScreen);
            this.ChatGlobalBox.Controls.Add(this.GlobalBtn);
            this.ChatGlobalBox.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.ChatGlobalBox.Location = new System.Drawing.Point(389, 326);
            this.ChatGlobalBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ChatGlobalBox.Name = "ChatGlobalBox";
            this.ChatGlobalBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ChatGlobalBox.Size = new System.Drawing.Size(228, 293);
            this.ChatGlobalBox.TabIndex = 54;
            this.ChatGlobalBox.TabStop = false;
            this.ChatGlobalBox.Text = "Chat Global";
            // 
            // Invitadoslbl
            // 
            this.Invitadoslbl.AutoSize = true;
            this.Invitadoslbl.Location = new System.Drawing.Point(579, 106);
            this.Invitadoslbl.Name = "Invitadoslbl";
            this.Invitadoslbl.Size = new System.Drawing.Size(64, 16);
            this.Invitadoslbl.TabIndex = 55;
            this.Invitadoslbl.Text = "personas";
            this.Invitadoslbl.Click += new System.EventHandler(this.Invitadoslbl_Click);
            // 
            // AnadirInvitadoBtn
            // 
            this.AnadirInvitadoBtn.Location = new System.Drawing.Point(579, 47);
            this.AnadirInvitadoBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AnadirInvitadoBtn.Name = "AnadirInvitadoBtn";
            this.AnadirInvitadoBtn.Size = new System.Drawing.Size(180, 57);
            this.AnadirInvitadoBtn.TabIndex = 56;
            this.AnadirInvitadoBtn.Text = "Enviar Solicitudes";
            this.AnadirInvitadoBtn.UseVisualStyleBackColor = true;
            this.AnadirInvitadoBtn.Click += new System.EventHandler(this.AnadirInvitadoBtn_Click);
            // 
            // ChatLocalBox
            // 
            this.ChatLocalBox.Controls.Add(this.LocalMsg);
            this.ChatLocalBox.Controls.Add(this.LocalBtn);
            this.ChatLocalBox.Controls.Add(this.LocalScreen);
            this.ChatLocalBox.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.ChatLocalBox.Location = new System.Drawing.Point(627, 326);
            this.ChatLocalBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ChatLocalBox.Name = "ChatLocalBox";
            this.ChatLocalBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ChatLocalBox.Size = new System.Drawing.Size(232, 293);
            this.ChatLocalBox.TabIndex = 57;
            this.ChatLocalBox.TabStop = false;
            this.ChatLocalBox.Text = "Chat Local";
            // 
            // LocalBtn
            // 
            this.LocalBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LocalBtn.Location = new System.Drawing.Point(172, 242);
            this.LocalBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LocalBtn.Name = "LocalBtn";
            this.LocalBtn.Size = new System.Drawing.Size(50, 42);
            this.LocalBtn.TabIndex = 48;
            this.LocalBtn.Text = "Enviar";
            this.LocalBtn.UseVisualStyleBackColor = true;
            this.LocalBtn.Click += new System.EventHandler(this.LocalBtn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(395, 12);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(162, 16);
            this.label8.TabIndex = 58;
            this.label8.Text = "¿Cón quien quieres jugar?";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Mongolian Baiti", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(202, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 14);
            this.label7.TabIndex = 60;
            this.label7.Text = "Usuario:";
            // 
            // EmpezarPartidaBtn
            // 
            this.EmpezarPartidaBtn.BackgroundImage = global::ProjecteClient.Properties.Resources.R;
            this.EmpezarPartidaBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpezarPartidaBtn.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.EmpezarPartidaBtn.Location = new System.Drawing.Point(657, 186);
            this.EmpezarPartidaBtn.Name = "EmpezarPartidaBtn";
            this.EmpezarPartidaBtn.Size = new System.Drawing.Size(174, 56);
            this.EmpezarPartidaBtn.TabIndex = 59;
            this.EmpezarPartidaBtn.Text = "Jugar";
            this.EmpezarPartidaBtn.UseVisualStyleBackColor = true;
            this.EmpezarPartidaBtn.Click += new System.EventHandler(this.EmpezarPartidaBtn_Click);
            // 
            // B2
            // 
            this.B2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.B2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.B2.Location = new System.Drawing.Point(145, 382);
            this.B2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(49, 52);
            this.B2.TabIndex = 248;
            this.B2.TabStop = false;
            this.B2.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // A2
            // 
            this.A2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.A2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A2.Location = new System.Drawing.Point(43, 381);
            this.A2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(49, 52);
            this.A2.TabIndex = 247;
            this.A2.TabStop = false;
            this.A2.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // B1
            // 
            this.B1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.B1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.B1.Location = new System.Drawing.Point(145, 485);
            this.B1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(49, 52);
            this.B1.TabIndex = 246;
            this.B1.TabStop = false;
            this.B1.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // A1
            // 
            this.A1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.A1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A1.Location = new System.Drawing.Point(43, 484);
            this.A1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(49, 52);
            this.A1.TabIndex = 245;
            this.A1.TabStop = false;
            this.A1.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // F6
            // 
            this.F6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.F6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.F6.Location = new System.Drawing.Point(554, 40);
            this.F6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.F6.Name = "F6";
            this.F6.Size = new System.Drawing.Size(49, 52);
            this.F6.TabIndex = 244;
            this.F6.TabStop = false;
            this.F6.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // E6
            // 
            this.E6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.E6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.E6.Location = new System.Drawing.Point(451, 41);
            this.E6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.E6.Name = "E6";
            this.E6.Size = new System.Drawing.Size(49, 52);
            this.E6.TabIndex = 243;
            this.E6.TabStop = false;
            this.E6.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // D6
            // 
            this.D6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.D6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.D6.Location = new System.Drawing.Point(348, 41);
            this.D6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.D6.Name = "D6";
            this.D6.Size = new System.Drawing.Size(49, 52);
            this.D6.TabIndex = 242;
            this.D6.TabStop = false;
            this.D6.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // C6
            // 
            this.C6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.C6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.C6.Location = new System.Drawing.Point(248, 41);
            this.C6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(49, 52);
            this.C6.TabIndex = 241;
            this.C6.TabStop = false;
            this.C6.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // F5
            // 
            this.F5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.F5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.F5.Location = new System.Drawing.Point(554, 114);
            this.F5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.F5.Name = "F5";
            this.F5.Size = new System.Drawing.Size(49, 52);
            this.F5.TabIndex = 240;
            this.F5.TabStop = false;
            this.F5.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // E5
            // 
            this.E5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.E5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.E5.Location = new System.Drawing.Point(451, 115);
            this.E5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.E5.Name = "E5";
            this.E5.Size = new System.Drawing.Size(49, 52);
            this.E5.TabIndex = 239;
            this.E5.TabStop = false;
            this.E5.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // D5
            // 
            this.D5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.D5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.D5.Location = new System.Drawing.Point(348, 115);
            this.D5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.D5.Name = "D5";
            this.D5.Size = new System.Drawing.Size(49, 52);
            this.D5.TabIndex = 238;
            this.D5.TabStop = false;
            this.D5.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // C5
            // 
            this.C5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.C5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.C5.Location = new System.Drawing.Point(248, 115);
            this.C5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(49, 52);
            this.C5.TabIndex = 237;
            this.C5.TabStop = false;
            this.C5.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // F4
            // 
            this.F4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.F4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.F4.Location = new System.Drawing.Point(554, 201);
            this.F4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.F4.Name = "F4";
            this.F4.Size = new System.Drawing.Size(49, 52);
            this.F4.TabIndex = 236;
            this.F4.TabStop = false;
            this.F4.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // F3
            // 
            this.F3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.F3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.F3.Location = new System.Drawing.Point(554, 284);
            this.F3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.F3.Name = "F3";
            this.F3.Size = new System.Drawing.Size(49, 52);
            this.F3.TabIndex = 235;
            this.F3.TabStop = false;
            this.F3.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // E4
            // 
            this.E4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.E4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.E4.Location = new System.Drawing.Point(451, 202);
            this.E4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.E4.Name = "E4";
            this.E4.Size = new System.Drawing.Size(49, 52);
            this.E4.TabIndex = 234;
            this.E4.TabStop = false;
            this.E4.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // D4
            // 
            this.D4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.D4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.D4.Location = new System.Drawing.Point(348, 202);
            this.D4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.D4.Name = "D4";
            this.D4.Size = new System.Drawing.Size(49, 52);
            this.D4.TabIndex = 233;
            this.D4.TabStop = false;
            this.D4.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // C4
            // 
            this.C4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.C4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.C4.Location = new System.Drawing.Point(248, 202);
            this.C4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(49, 52);
            this.C4.TabIndex = 232;
            this.C4.TabStop = false;
            this.C4.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // E3
            // 
            this.E3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.E3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.E3.Location = new System.Drawing.Point(451, 285);
            this.E3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.E3.Name = "E3";
            this.E3.Size = new System.Drawing.Size(49, 52);
            this.E3.TabIndex = 231;
            this.E3.TabStop = false;
            this.E3.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // B5
            // 
            this.B5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.B5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.B5.Location = new System.Drawing.Point(145, 115);
            this.B5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(49, 52);
            this.B5.TabIndex = 227;
            this.B5.TabStop = false;
            this.B5.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // B4
            // 
            this.B4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.B4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.B4.Location = new System.Drawing.Point(145, 202);
            this.B4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(49, 52);
            this.B4.TabIndex = 226;
            this.B4.TabStop = false;
            this.B4.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // A6
            // 
            this.A6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.A6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A6.Location = new System.Drawing.Point(43, 40);
            this.A6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.A6.Name = "A6";
            this.A6.Size = new System.Drawing.Size(49, 52);
            this.A6.TabIndex = 229;
            this.A6.TabStop = false;
            this.A6.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // A3
            // 
            this.A3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.A3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A3.Location = new System.Drawing.Point(43, 284);
            this.A3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(49, 52);
            this.A3.TabIndex = 228;
            this.A3.TabStop = false;
            this.A3.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // B6
            // 
            this.B6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.B6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.B6.Location = new System.Drawing.Point(145, 41);
            this.B6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(49, 52);
            this.B6.TabIndex = 225;
            this.B6.TabStop = false;
            this.B6.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // C3
            // 
            this.C3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.C3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.C3.Location = new System.Drawing.Point(248, 285);
            this.C3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(49, 52);
            this.C3.TabIndex = 230;
            this.C3.TabStop = false;
            this.C3.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // A5
            // 
            this.A5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.A5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A5.Location = new System.Drawing.Point(43, 114);
            this.A5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(49, 52);
            this.A5.TabIndex = 222;
            this.A5.TabStop = false;
            this.A5.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // B3
            // 
            this.B3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.B3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.B3.Location = new System.Drawing.Point(145, 285);
            this.B3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(49, 52);
            this.B3.TabIndex = 223;
            this.B3.TabStop = false;
            this.B3.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // A4
            // 
            this.A4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.A4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.A4.Location = new System.Drawing.Point(43, 201);
            this.A4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(49, 52);
            this.A4.TabIndex = 224;
            this.A4.TabStop = false;
            this.A4.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // D3
            // 
            this.D3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.D3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.D3.Location = new System.Drawing.Point(348, 285);
            this.D3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.D3.Name = "D3";
            this.D3.Size = new System.Drawing.Size(49, 52);
            this.D3.TabIndex = 213;
            this.D3.TabStop = false;
            this.D3.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // E1
            // 
            this.E1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.E1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.E1.Location = new System.Drawing.Point(451, 485);
            this.E1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.E1.Name = "E1";
            this.E1.Size = new System.Drawing.Size(49, 52);
            this.E1.TabIndex = 214;
            this.E1.TabStop = false;
            this.E1.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // E2
            // 
            this.E2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.E2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.E2.Location = new System.Drawing.Point(451, 382);
            this.E2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.E2.Name = "E2";
            this.E2.Size = new System.Drawing.Size(49, 52);
            this.E2.TabIndex = 218;
            this.E2.TabStop = false;
            this.E2.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // D2
            // 
            this.D2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.D2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.D2.Location = new System.Drawing.Point(348, 382);
            this.D2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.D2.Name = "D2";
            this.D2.Size = new System.Drawing.Size(49, 52);
            this.D2.TabIndex = 217;
            this.D2.TabStop = false;
            this.D2.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // C2
            // 
            this.C2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.C2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.C2.Location = new System.Drawing.Point(248, 382);
            this.C2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(49, 52);
            this.C2.TabIndex = 219;
            this.C2.TabStop = false;
            this.C2.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // F2
            // 
            this.F2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.F2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.F2.Location = new System.Drawing.Point(554, 381);
            this.F2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.F2.Name = "F2";
            this.F2.Size = new System.Drawing.Size(49, 52);
            this.F2.TabIndex = 221;
            this.F2.TabStop = false;
            this.F2.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // F1
            // 
            this.F1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.F1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.F1.Location = new System.Drawing.Point(554, 484);
            this.F1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.F1.Name = "F1";
            this.F1.Size = new System.Drawing.Size(49, 52);
            this.F1.TabIndex = 215;
            this.F1.TabStop = false;
            this.F1.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // D1
            // 
            this.D1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.D1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.D1.Location = new System.Drawing.Point(348, 485);
            this.D1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.D1.Name = "D1";
            this.D1.Size = new System.Drawing.Size(49, 52);
            this.D1.TabIndex = 220;
            this.D1.TabStop = false;
            this.D1.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // C1
            // 
            this.C1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.C1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.C1.Location = new System.Drawing.Point(248, 485);
            this.C1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(49, 52);
            this.C1.TabIndex = 216;
            this.C1.TabStop = false;
            this.C1.Click += new System.EventHandler(this.PonerFichaClick);
            // 
            // PColorBox
            // 
            this.PColorBox.Location = new System.Drawing.Point(713, 29);
            this.PColorBox.Name = "PColorBox";
            this.PColorBox.Size = new System.Drawing.Size(48, 49);
            this.PColorBox.TabIndex = 61;
            this.PColorBox.TabStop = false;
            // 
            // DisconectBtn
            // 
            this.DisconectBtn.BackgroundImage = global::ProjecteClient.Properties.Resources.pngtree_on_off_button_vector_png_image_67gyu02128__2___1_;
            this.DisconectBtn.Location = new System.Drawing.Point(178, 35);
            this.DisconectBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DisconectBtn.Name = "DisconectBtn";
            this.DisconectBtn.Size = new System.Drawing.Size(142, 138);
            this.DisconectBtn.TabIndex = 8;
            this.DisconectBtn.UseVisualStyleBackColor = true;
            this.DisconectBtn.Click += new System.EventHandler(this.DisconectBtn_Click);
            // 
            // SigInBtn
            // 
            this.SigInBtn.BackgroundImage = global::ProjecteClient.Properties.Resources._10423381;
            this.SigInBtn.Location = new System.Drawing.Point(178, 186);
            this.SigInBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SigInBtn.Name = "SigInBtn";
            this.SigInBtn.Size = new System.Drawing.Size(151, 131);
            this.SigInBtn.TabIndex = 7;
            this.SigInBtn.UseVisualStyleBackColor = true;
            this.SigInBtn.Click += new System.EventHandler(this.SigInBtn_Click);
            // 
            // LogInBtn
            // 
            this.LogInBtn.Image = global::ProjecteClient.Properties.Resources.user_profile_icon_free_vector;
            this.LogInBtn.Location = new System.Drawing.Point(11, 186);
            this.LogInBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LogInBtn.Name = "LogInBtn";
            this.LogInBtn.Size = new System.Drawing.Size(161, 131);
            this.LogInBtn.TabIndex = 5;
            this.LogInBtn.Text = "   \r\n\r\n\r\n\r\n\r\n\r\n";
            this.LogInBtn.UseVisualStyleBackColor = true;
            this.LogInBtn.Click += new System.EventHandler(this.LogInBtn_Click);
            // 
            // Connect_btn
            // 
            this.Connect_btn.BackgroundImage = global::ProjecteClient.Properties.Resources.on__3_;
            this.Connect_btn.ForeColor = System.Drawing.Color.Cornsilk;
            this.Connect_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Connect_btn.Location = new System.Drawing.Point(21, 35);
            this.Connect_btn.Margin = new System.Windows.Forms.Padding(2, 2, 3, 2);
            this.Connect_btn.Name = "Connect_btn";
            this.Connect_btn.Size = new System.Drawing.Size(151, 138);
            this.Connect_btn.TabIndex = 0;
            this.Connect_btn.UseVisualStyleBackColor = true;
            this.Connect_btn.Click += new System.EventHandler(this.Connect_btn_Click);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1774, 642);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.EmpezarPartidaBtn);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.AnadirInvitadoBtn);
            this.Controls.Add(this.ChatLocalBox);
            this.Controls.Add(this.Invitadoslbl);
            this.Controls.Add(this.ChatGlobalBox);
            this.Controls.Add(this.Usuariolbl);
            this.Controls.Add(this.GrupoJuegoBox);
            this.Controls.Add(this.InvitacionBox);
            this.Controls.Add(this.GroupLogSignInBox);
            this.Controls.Add(this.ListaConectados);
            this.Controls.Add(this.ConexionActual);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DisconectBtn);
            this.Controls.Add(this.SigInBtn);
            this.Controls.Add(this.LogInBtn);
            this.Controls.Add(this.Connect_btn);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormPrincipal";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ListaConectados)).EndInit();
            this.GroupLogSignInBox.ResumeLayout(false);
            this.GroupLogSignInBox.PerformLayout();
            this.InvitacionBox.ResumeLayout(false);
            this.InvitacionBox.PerformLayout();
            this.GrupoJuegoBox.ResumeLayout(false);
            this.GrupoJuegoBox.PerformLayout();
            this.ChatGlobalBox.ResumeLayout(false);
            this.ChatGlobalBox.PerformLayout();
            this.ChatLocalBox.ResumeLayout(false);
            this.ChatLocalBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.B2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.A4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.E2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PColorBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Connect_btn;
        private System.Windows.Forms.Button LogInBtn;
        private System.Windows.Forms.Button SigInBtn;
        private System.Windows.Forms.Button DisconectBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel ConexionActual;
        private System.Windows.Forms.DataGridView ListaConectados;
        private System.Windows.Forms.GroupBox GroupLogSignInBox;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button LogSignInBtn;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox InvitacionBox;
        private System.Windows.Forms.Button RejectGameBtn;
        private System.Windows.Forms.Button GameAcceptBtn;
        private System.Windows.Forms.Label InvitacionLbl1;
        private System.Windows.Forms.Label InvitacionLbl2;
        private System.Windows.Forms.GroupBox GrupoJuegoBox;
        private System.Windows.Forms.TextBox LocalMsg;
        private System.Windows.Forms.TextBox LocalScreen;
        private System.Windows.Forms.Label Usuariolbl;
        private System.Windows.Forms.TextBox GlobalScreen;
        private System.Windows.Forms.TextBox GlobalMsg;
        private System.Windows.Forms.Button GlobalBtn;
        private System.Windows.Forms.GroupBox ChatGlobalBox;
        private System.Windows.Forms.Label Invitadoslbl;
        private System.Windows.Forms.Button AnadirInvitadoBtn;
        private System.Windows.Forms.GroupBox ChatLocalBox;
        private System.Windows.Forms.Button LocalBtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox PColorBox;
        private System.Windows.Forms.Label TuColorLbl;
        private System.Windows.Forms.PictureBox B2;
        private System.Windows.Forms.PictureBox A2;
        private System.Windows.Forms.PictureBox B1;
        private System.Windows.Forms.PictureBox A1;
        private System.Windows.Forms.PictureBox F6;
        private System.Windows.Forms.PictureBox E6;
        private System.Windows.Forms.PictureBox D6;
        private System.Windows.Forms.PictureBox C6;
        private System.Windows.Forms.PictureBox F5;
        private System.Windows.Forms.PictureBox E5;
        private System.Windows.Forms.PictureBox D5;
        private System.Windows.Forms.PictureBox C5;
        private System.Windows.Forms.PictureBox F4;
        private System.Windows.Forms.PictureBox F3;
        private System.Windows.Forms.PictureBox E4;
        private System.Windows.Forms.PictureBox D4;
        private System.Windows.Forms.PictureBox C4;
        private System.Windows.Forms.PictureBox E3;
        private System.Windows.Forms.PictureBox B5;
        private System.Windows.Forms.PictureBox B4;
        private System.Windows.Forms.PictureBox A6;
        private System.Windows.Forms.PictureBox A3;
        private System.Windows.Forms.PictureBox B6;
        private System.Windows.Forms.PictureBox C3;
        private System.Windows.Forms.PictureBox A5;
        private System.Windows.Forms.PictureBox B3;
        private System.Windows.Forms.PictureBox A4;
        private System.Windows.Forms.PictureBox D3;
        private System.Windows.Forms.PictureBox E1;
        private System.Windows.Forms.PictureBox E2;
        private System.Windows.Forms.PictureBox D2;
        private System.Windows.Forms.PictureBox C2;
        private System.Windows.Forms.PictureBox F2;
        private System.Windows.Forms.PictureBox F1;
        private System.Windows.Forms.PictureBox D1;
        private System.Windows.Forms.PictureBox C1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button EmpezarPartidaBtn;
    }
}

