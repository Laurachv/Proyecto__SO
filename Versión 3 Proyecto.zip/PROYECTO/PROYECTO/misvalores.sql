INSERT INTO jugadores (`user`) VALUES ('@nombrejugador');
SELECT LAST_INSERT_ID() AS id_jugador;
