using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace cliente
{
    public partial class Form1 : Form
    {
        Socket server; //Creamos el socket
        public bool sesion;
        Thread atender; //Creamos el thread
        private List<string> jugadoresOnline = new List<string>();

        public Form1()
        {
            InitializeComponent();
        }

        public void AtenderServidor()
        {
            while (true)
            {
                byte[] msg2 = new byte[1024];
                int bytesRecibidos = server.Receive(msg2);
                string respuesta = Encoding.ASCII.GetString(msg2, 0, bytesRecibidos);

                string[] trozos = respuesta.Split('/');
                int codigo = 0;

                if (trozos.Length > 0 && int.TryParse(trozos[0], out codigo))
                {
                    if (codigo == 0)
                    {
                        MessageBox.Show("Desconexi�n del servidor.");
                        break;
                    }
                    else if (codigo == 1)
                    {
                        if (trozos.Length > 1 && trozos[1] == "OK")
                        {
                            MessageBox.Show("Inicio de sesi�n exitoso.");
                        }
                        else
                        {

                        }
                    }
                    else if (codigo == 2)
                    {
                        if (trozos.Length > 1 && trozos[1] == "ERROR")
                        {
                            MessageBox.Show("El nombre de usuario ya est� en uso.");
                        }
                        else
                        {
                            MessageBox.Show("Registro exitoso.");
                        }
                    }
                    else if (codigo == 5)
                    {
                        jugadoresOnline.Clear();

                        if (trozos.Length > 1 && trozos[1] == "1")
                        {
                            Invoke((Action)delegate {
                                MessageBox.Show("No hay usuarios conectados.");
                            });
                        }
                        else
                        {
                            for (int i = 1; i < trozos.Length; i++)
                            {
                                jugadoresOnline.Add(trozos[i]);
                            }

                            Invoke((Action)delegate {
                                string mensajeMostrar = string.Join(Environment.NewLine, jugadoresOnline);
                                MessageBox.Show(mensajeMostrar, "Online Players");
                            });
                        }
                    }
                }
            }
        }

        private void conectar_Click(object sender, EventArgs e)
        {
            IPAddress direc = IPAddress.Parse("192.168.56.102"); // IP del servidor
            IPEndPoint ipep = new IPEndPoint(direc, 9020);
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            try
            {
                server.Connect(ipep);
                this.BackColor = Color.LightGreen;
                MessageBox.Show("Conectado");

                ThreadStart ts = delegate { AtenderServidor(); };
                atender = new Thread(ts);
                atender.Start();
            }
            catch (SocketException ex)
            {
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
        }

        private void desconectar_Click(object sender, EventArgs e)
        {
            if (server != null && server.Connected)
            {
                string mensaje = "0/";
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                this.BackColor = Color.LightGray;
                server.Shutdown(SocketShutdown.Both);
                server.Close();
                MessageBox.Show("Desconectado");
            }
            else
            {
                MessageBox.Show("Desconexi�n fallida");
            }
        }

        private void signup_Click(object sender, EventArgs e)
        {
            SignUp signupform = new SignUp(this);
            signupform.ShowDialog();
        }

        public int Registrarse(string nick, string pass)
        {
            string mensaje = "1/" + nick + "/" + pass;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];

            if (mensaje == "1")
                return 1;
            else if (mensaje == "2")
                return 2;
            else
                return 3;
        }

        private void login_Click(object sender, EventArgs e)
        {
            LogIn logInform = new LogIn(this);
            logInform.ShowDialog();
        }

        public int LogIn(string nick, string pass)
        {
            string mensaje = "2/" + nick + "/" + pass;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];

            if (mensaje == "1")
            {
                sesion = true;
                return 1;
            }
            else if (mensaje == "2")
                return 2;
            else
                return 3;
        }

        private async void online_Click(object sender, EventArgs e)
        {
            if (server != null && server.Connected)
            {
                try
                {
                    string mensaje = "5/";
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);

                    // Enviar el mensaje al servidor en un hilo separado
                    await Task.Run(() =>
                    {
                        server.Send(msg);

                        // Recibir la respuesta del servidor
                        byte[] msg2 = new byte[80];
                        int bytesRecibidos = server.Receive(msg2);

                        // Convertir la respuesta en una cadena y procesar los datos
                        mensaje = Encoding.ASCII.GetString(msg2, 0, bytesRecibidos).Split('\0')[0];
                    });

                    // Procesar la respuesta del servidor en el hilo principal
                    string[] partes = mensaje.Split('/');

                    // Crear un mensaje combinado para mostrar en el MessageBox
                    string mensajeMostrar = string.Join(Environment.NewLine, partes);

                    // Mostrar el mensaje en un MessageBox
                    Invoke(new Action(() =>
                    {
                        MessageBox.Show(mensajeMostrar, "Online Players");
                    }));
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error en la comunicaci�n con el servidor: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("No hay conexi�n con el servidor.");
            }
        }
    }
}
