﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cliente
{
    public partial class SignUp : Form
    {
        private Form1 form1;

        public SignUp(Form1 mainform)
        {
            InitializeComponent();
            this.form1 = mainform;
        }

        private void Registrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsuario.Text) || string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Datos no proporcionados.");
            }
            else
            {
                // Ejecutar el registro en un hilo secundario para no congelar la UI
                Task.Run(() => RealizarRegistro(txtUsuario.Text, txtPassword.Text));
            }
        }

        private void RealizarRegistro(string usuario, string password)
        {
            try
            {
                int compl = form1.Registrarse(usuario, password);

                // Volver al hilo principal para mostrar mensajes o cerrar el formulario
                this.Invoke((MethodInvoker)delegate
                {
                    if (compl == 1)
                    {
                        MessageBox.Show("Registro completado.");
                        this.Close();
                    }
                    else if (compl == 2)
                    {
                        MessageBox.Show("Nickname ya usado.");
                    }
                    else
                    {
                        MessageBox.Show("Error al registrarse.");
                    }
                });
            }
            catch
            {
                this.Invoke((MethodInvoker)delegate
                {
                    MessageBox.Show("Error al registrarse.");
                });
            }
        }
        private void volver1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}