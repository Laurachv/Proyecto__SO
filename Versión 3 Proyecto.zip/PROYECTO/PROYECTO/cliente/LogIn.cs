﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cliente
{
    public partial class LogIn : Form
    {
        private Form1 form1;

        public LogIn(Form1 mainform)
        {
            InitializeComponent();
            this.form1 = mainform; 
        }

        private void insesion_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsuario.Text) || string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Datos no proporcionados.");
            }
            else
            {
                // Ejecutar en segundo plano
                Task.Run(() => RealizarLogin(txtUsuario.Text, txtPassword.Text));
            }
        }

        private void RealizarLogin(string usuario, string password)
        {
            try
            {
                int compl = form1.LogIn(usuario, password);

                // Volver al hilo de la UI para actualizar
                this.Invoke((MethodInvoker)delegate
                {
                    if (compl == 1)
                    {
                        MessageBox.Show("Sesión iniciada.");
                        this.Close();
                    }
                    else if (compl == 2)
                    {
                        MessageBox.Show("Nickname incorrecto.");
                    }
                    else if (compl == 3)
                    {
                        MessageBox.Show("Password incorrecto.");
                    }
                    else
                    {
                        MessageBox.Show("Error al iniciar sesión.");
                    }
                });
            }
            catch
            {
                this.Invoke((MethodInvoker)delegate
                {
                    MessageBox.Show("Error al iniciar sesión.");
                });
            }
        }

        private void volver2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
