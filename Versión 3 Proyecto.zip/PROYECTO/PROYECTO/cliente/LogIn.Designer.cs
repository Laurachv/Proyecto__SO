﻿namespace cliente
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPassword = new TextBox();
            txtUsuario = new TextBox();
            volver2 = new Button();
            insesion = new Button();
            password = new Label();
            usuario = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(315, 296);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(150, 31);
            txtPassword.TabIndex = 13;
            // 
            // txtUsuario
            // 
            txtUsuario.Location = new Point(315, 170);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.Size = new Size(150, 31);
            txtUsuario.TabIndex = 12;
            // 
            // volver2
            // 
            volver2.Location = new Point(555, 406);
            volver2.Name = "volver2";
            volver2.Size = new Size(229, 34);
            volver2.TabIndex = 11;
            volver2.Text = "Volver a menú principal";
            volver2.UseVisualStyleBackColor = true;
            volver2.Click += volver2_Click_1;
            // 
            // insesion
            // 
            insesion.Location = new Point(307, 355);
            insesion.Name = "insesion";
            insesion.Size = new Size(158, 34);
            insesion.TabIndex = 10;
            insesion.Text = "Iniciar Sesión";
            insesion.UseVisualStyleBackColor = true;
            insesion.Click += insesion_Click_1;
            // 
            // password
            // 
            password.AutoSize = true;
            password.Location = new Point(329, 227);
            password.Name = "password";
            password.Size = new Size(101, 25);
            password.TabIndex = 9;
            password.Text = "Contraseña";
            // 
            // usuario
            // 
            usuario.AutoSize = true;
            usuario.Location = new Point(353, 120);
            usuario.Name = "usuario";
            usuario.Size = new Size(72, 25);
            usuario.TabIndex = 8;
            usuario.Text = "Usuario";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 28F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(17, 11);
            label1.Name = "label1";
            label1.Size = new Size(186, 74);
            label1.TabIndex = 7;
            label1.Text = "Log In";
            // 
            // LogIn
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtPassword);
            Controls.Add(txtUsuario);
            Controls.Add(volver2);
            Controls.Add(insesion);
            Controls.Add(password);
            Controls.Add(usuario);
            Controls.Add(label1);
            Name = "LogIn";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPassword;
        private TextBox txtUsuario;
        private Button volver2;
        private Button insesion;
        private Label password;
        private Label usuario;
        private Label label1;
    }
}