﻿namespace cliente
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            conectar = new Button();
            desconectar = new Button();
            signup = new Button();
            login = new Button();
            online = new Button();
            SuspendLayout();
            // 
            // conectar
            // 
            conectar.Location = new Point(37, 50);
            conectar.Name = "conectar";
            conectar.Size = new Size(111, 37);
            conectar.TabIndex = 0;
            conectar.Text = "Conectar";
            conectar.UseVisualStyleBackColor = true;
            conectar.Click += conectar_Click;
            // 
            // desconectar
            // 
            desconectar.Location = new Point(183, 51);
            desconectar.Name = "desconectar";
            desconectar.Size = new Size(116, 36);
            desconectar.TabIndex = 1;
            desconectar.Text = "Desconectar";
            desconectar.UseVisualStyleBackColor = true;
            desconectar.Click += desconectar_Click;
            // 
            // signup
            // 
            signup.Location = new Point(667, 24);
            signup.Name = "signup";
            signup.Size = new Size(111, 37);
            signup.TabIndex = 2;
            signup.Text = "Sign Up";
            signup.UseVisualStyleBackColor = true;
            signup.Click += signup_Click;
            // 
            // login
            // 
            login.Location = new Point(667, 76);
            login.Name = "login";
            login.Size = new Size(112, 34);
            login.TabIndex = 3;
            login.Text = "Log In";
            login.UseVisualStyleBackColor = true;
            login.Click += login_Click;
            // 
            // online
            // 
            online.Location = new Point(433, 24);
            online.Name = "online";
            online.Size = new Size(112, 60);
            online.TabIndex = 4;
            online.Text = "Jugadores Online";
            online.UseVisualStyleBackColor = true;
            online.Click += online_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(online);
            Controls.Add(login);
            Controls.Add(signup);
            Controls.Add(desconectar);
            Controls.Add(conectar);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button conectar;
        private Button desconectar;
        private Button signup;
        private Button login;
        private Button online;
    }
}
