DROP DATABASE IF EXISTS mistablas;
CREATE DATABASE mistablas;
USE mistablas;

-- Tabla de DB_players
CREATE TABLE DB_players(
    Usuario VARCHAR(25),
	ID_jugador VARCHAR(10),
	Password VARCHAR(10),
);

