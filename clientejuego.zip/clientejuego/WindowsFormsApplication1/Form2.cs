﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        int nForm;
        Socket server;

        // Variable estática para asignar IDs de jugadores
        static int jugadorID = 0;  // Este contador asigna ID de manera secuencial a los jugadores

        List<Form3> formularios = new List<Form3>();
        public Form2(int nForm, Socket server)
        {
            InitializeComponent();
            this.nForm = nForm;
            this.server = server;
        }

        // Al cargar el formulario, mostramos el número de formulario
        private void Form2_Load(object sender, EventArgs e)
        {
        }

        // Función para asignar un ID al jugador basado en el mensaje recibido
       // public void AsignaID_Jugador(string mensaje)
        //{
          //  mensaje = mensaje.Trim().ToUpper(); // Normaliza el mensaje recibido
            //int id = 0;

            // Si el mensaje indica que el nombre es válido (por ejemplo, "SI")
            //if (mensaje == "SI")
            //{
                // Asignamos un nuevo ID y lo incrementamos
              //  id = ++jugadorID;

                // Mostramos el ID asignado al jugador
                //MessageBox.Show($"HAS RECIBIDO ID_JUGADOR: {id}");

                // Enviar el ID al servidor
                //EnviarIDServidor(id);
           // }
            //else
            //{
                // Si el mensaje no es "SI", mostramos un mensaje de error
                //MessageBox.Show("PRUEBA OTRO NOMBRE");
            //}
        //}

        // Función para enviar el ID del jugador al servidor
        private void EnviarIDServidor(int id)
        {
            // Enviar el ID al servidor (puedes usar un mensaje o protocolo específico)
            byte[] idBytes = Encoding.ASCII.GetBytes(id.ToString());
            server.Send(idBytes);
        }

        // Este método se activa con un botón para validar el nombre y asignar ID
        private void button2_Click(object sender, EventArgs e)
        {
            // Obtener el nombre sin espacios extras

            // Mensaje de depuración (opcional)


            // Llamar a la función AsignaID_Jugador con el nombre recibido
            //AsignaID_Jugador(nombre);

            // Enviar ID al servidor (si aplica)


            // Abrir Formulario3 y pasar el nombre, aunque esté vacío
           
            int cont = formularios.Count;
            Form3 f = new Form3(cont);
            formularios.Add(f);
            f.ShowDialog();
        }

        // Cerrar Form2 si no es necesario después de abrir Form3

    }





       
       
    }

