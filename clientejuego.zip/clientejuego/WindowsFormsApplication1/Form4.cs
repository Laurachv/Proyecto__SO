﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form4: Form
    {
        List<Form5> formularios = new List<Form5>();
        List<Form6> formulario = new List<Form6>();
        public Form4(int cont)
        {
            InitializeComponent();

        }


        private void Form4_Load(object sender, EventArgs e)
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int cont = formularios.Count;
            Form5 f1 = new Form5(cont);
            formularios.Add(f1);
            f1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            int cont = formulario.Count; // Usar la lista correcta (formulario)
            Form6 f2 = new Form6(cont);
            formulario.Add(f2); // Agregar a la lista de Form6
            f2.ShowDialog();
           

        }
    }
}
