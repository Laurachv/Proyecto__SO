﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form3: Form
    {
        List<Form4> formularios = new List<Form4>();
        List<Form5> formulario = new List<Form5>();
        
        public Form3(int cont)
        {
            InitializeComponent();
            
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int cont = formularios.Count;
            Form4 f4 = new Form4(cont);
            formularios.Add(f4);
            f4.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int cont = formularios.Count;
            Form4 f4 = new Form4(cont);
            formularios.Add(f4);
            f4.ShowDialog();
        }
    }
}
