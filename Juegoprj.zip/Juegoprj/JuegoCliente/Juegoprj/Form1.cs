﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Juegoprj
{
    public partial class Form1 : Form
    {
        Socket server; //Creamos el socket
        Thread atender; //Creamos el thread

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        public void AtenderServidor()
        {
            while (true)
            {
                byte[] msg2 = new byte[1024];  // Asegúrate de que el tamaño del buffer sea suficiente
                int bytesRecibidos = server.Receive(msg2); // Recibimos mensaje del servidor
                string respuesta = Encoding.ASCII.GetString(msg2, 0, bytesRecibidos);

                string[] trozos = respuesta.Split('/');
                int codigo = 0;

                // Verificar que el primer trozo es un número
                if (trozos.Length > 0 && int.TryParse(trozos[0], out codigo))
                {
                    // Si el código recibido es 0, mostramos un mensaje de desconexión
                    if (codigo == 0) // Código de desconexión o error
                    {
                        MessageBox.Show("Desconexión del servidor.");
                        break;
                    }
                    // Verifica respuestas para registrar o iniciar sesión
                    if (codigo == 2)  // Respuesta para SignUp
                    {
                        if (trozos[1] == "ERROR")
                        {
                            MessageBox.Show("El nombre de usuario ya está en uso.");
                        }
                        else
                        {
                            MessageBox.Show("Registro exitoso.");
                        }
                    }
                    else if (codigo == 1)  // Respuesta para Login
                    {
                        if (trozos[1] == "OK")
                        {
                            MessageBox.Show("Inicio de sesión exitoso.");
                        }
                        else
                        {
                            MessageBox.Show("Usuario o contraseña incorrectos.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Error: Mensaje recibido con formato incorrecto.");
                }
            }
        }

        private int clickcount = 0; //Variable para controlar el número de clicks en el boton conectar

        private void Conectar_btn_Click(object sender, EventArgs e)
        {
            IPAddress direc = IPAddress.Parse("192.168.56.102"); //IP del servidor
            IPEndPoint ipep = new IPEndPoint(direc, 9010); //Puerto del servidor
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep); //Intentamos conectar el socket
                this.BackColor = Color.LightGreen;
                MessageBox.Show("Conectado");
                //pongo en marcha el thread que atenderá los mensajes del servidor
                ThreadStart ts = delegate { AtenderServidor(); };
                atender = new Thread(ts);
                atender.Start();
            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return; //Sale del programa
            }
        }

        private void Desconectar_btn_Click(object sender, EventArgs e)
        {
            if (server != null && server.Connected)
            {
                string mensaje = "0/";  // Enviar mensaje de desconexión
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                atender.Abort();
                this.BackColor = Color.LightGray;
                server.Shutdown(SocketShutdown.Both);
                server.Close();
                MessageBox.Show("Desconectado");
            }
            else
            {
                MessageBox.Show("Desconexion fallida");
            }
        }

        private void Sign_up_btn_Click(object sender, EventArgs e)
        {
            string nombreUsuario = txtUsuario.Text;
            string contraseña = txtPassword.Text;

            if (string.IsNullOrEmpty(nombreUsuario) || string.IsNullOrEmpty(contraseña))
            {
                MessageBox.Show("Por favor, ingrese un nombre de usuario y una contraseña.");
                return;
            }

            // Enviar mensaje de registro (Formateado como: 2/usuario/contraseña)
            string mensajeServidor = $"2/{nombreUsuario}/{contraseña}";
            byte[] msg = Encoding.ASCII.GetBytes(mensajeServidor);
            server.Send(msg); // Enviar los datos de registro al servidor
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            
        }

        private void Signupbtn_Click(object sender, EventArgs e)
        {
            string nombreUsuario = txtUsuario.Text;
            string contraseña = txtPassword.Text;

            if (string.IsNullOrEmpty(nombreUsuario) || string.IsNullOrEmpty(contraseña))
            {
                MessageBox.Show("Por favor, ingrese un nombre de usuario y una contraseña.");
                return;
            }

            // Enviar mensaje de registro (Formateado como: 2/usuario/contraseña)
            string mensajeServidor = $"2/{nombreUsuario}/{contraseña}";
            byte[] msg = Encoding.ASCII.GetBytes(mensajeServidor);
            server.Send(msg); // Enviar los datos de registro al servidor
        }

        private void Loginbtn_Click(object sender, EventArgs e)
        {
            string nombreUsuario = txtUsuario.Text;
            string contraseña = txtPassword.Text;

            if (string.IsNullOrEmpty(nombreUsuario) || string.IsNullOrEmpty(contraseña))
            {
                MessageBox.Show("Por favor, ingrese un nombre de usuario y una contraseña.");
                return;
            }

            // Enviar mensaje de login (Formateado como: 1/usuario/contraseña)
            string mensajeServidor = $"1/{nombreUsuario}/{contraseña}";
            byte[] msg = Encoding.ASCII.GetBytes(mensajeServidor);
            server.Send(msg); // Enviar los datos de login al servidor
        }
    }
}


